<?php

/**
 * PERMISSION ROLE MODAL
 */
class Permission_role_model extends MY_Model
{
    const DB_TABLE = 'permission_role';

    const DB_TABLE_PK = 'role_id';

    public $role_id;

    public $permission_id;

}
